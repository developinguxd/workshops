class <%= @klass %>; end
