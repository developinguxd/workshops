class Application < Base
end
